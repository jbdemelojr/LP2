package jdbcrowsettest;

import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import javax.sql.rowset.JdbcRowSet;
import com.sun.rowset.JdbcRowSetImpl;

public class JdbcRowSetTest {

    static final String DRIVER = "com.mysql.jdbc.Driver";
    static final String ENDERECO_BD = "jdbc:mysql://localhost:3307/livros";
    static final String USUARIO = "root";
    static final String SENHA = "";
    
    public JdbcRowSetTest(){
        try{
            
            Class.forName(DRIVER);
            
            JdbcRowSet objetoRowSet = new JdbcRowSetImpl();
            objetoRowSet.setUrl(ENDERECO_BD);
            objetoRowSet.setUsername(USUARIO);
            objetoRowSet.setPassword(SENHA);
            objetoRowSet.setCommand("SELECT * FROM autor");
            objetoRowSet.execute();
            
            ResultSetMetaData dadosSuperiores = objetoRowSet.getMetaData();
            int numeroColunas = dadosSuperiores.getColumnCount();
            System.out.println("Tabela de Autores: ");
            
            for(int i = 1; i <= numeroColunas; i++)
                System.out.printf("%-8s\t", dadosSuperiores.getColumnName(i));
                System.out.println();
                
            while (objetoRowSet.next()){
                for(int i = 1; i <= numeroColunas; i ++)
                    System.out.printf("%-8s\t",objetoRowSet.getObject(i));
                    System.out.println();
            }
        }
        
        catch(SQLException sqlException){
            sqlException.printStackTrace();
            System.exit(1);
        }
        
        catch(ClassNotFoundException erro){
            erro.printStackTrace();
            System.exit(1);
        }
    }
        
    public static void main(String[] args) {
        JdbcRowSetTest aplicativo = new JdbcRowSetTest();
    }
    
}
